﻿// See https://aka.ms/new-console-template for more information

interface IShape
{
    double GetArea();
}