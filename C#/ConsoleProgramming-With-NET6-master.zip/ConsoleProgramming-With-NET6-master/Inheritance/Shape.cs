﻿// See https://aka.ms/new-console-template for more information
abstract class Shape
{
    public double Height { get; set; }
    public double Length { get; set; }
}

