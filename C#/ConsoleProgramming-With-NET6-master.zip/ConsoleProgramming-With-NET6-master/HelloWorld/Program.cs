﻿// See https://aka.ms/new-console-template for more information

/*
    There are three control structures in C# Programming: Sequence, Decisions and Repitions
 */

// This line prints hello world
Console.WriteLine("Hello, World!");


// Test Modification
