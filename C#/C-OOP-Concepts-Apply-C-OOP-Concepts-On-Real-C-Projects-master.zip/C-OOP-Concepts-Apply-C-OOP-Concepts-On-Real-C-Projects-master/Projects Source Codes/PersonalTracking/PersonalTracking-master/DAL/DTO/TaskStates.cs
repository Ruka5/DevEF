﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DTO
{
  public static  class TaskStates
    {
        public static int OnEmployee = 1;
        public static int Delivered = 2;
        public static int Approved = 3;
    }
}
