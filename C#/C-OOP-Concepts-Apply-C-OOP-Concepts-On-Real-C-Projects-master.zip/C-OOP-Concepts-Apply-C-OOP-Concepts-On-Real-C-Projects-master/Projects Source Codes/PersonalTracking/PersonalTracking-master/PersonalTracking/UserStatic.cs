﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalTracking
{
   public static class UserStatic
    {
        public static int EmployeeID { get; set; }
        public static int UserNo { get; set; }
        public static bool isAdmin { get; set; }
    }
}
