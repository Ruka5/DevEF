﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockTracking.DAL.DAO
{
  public  class StockContext
    {
        public StockTrackingEntities1 db = new StockTrackingEntities1();
    }
}
